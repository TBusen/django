def useful_func():
    print("Using the useful_func!")

class UsefulClass():

    def __init__(self,message):
        self.message = message 

    def report(self):
        print(self.message) 